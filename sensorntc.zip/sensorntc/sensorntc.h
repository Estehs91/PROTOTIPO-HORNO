#ifndef sensorntc_h
#define sensorntc_h

#include "arduino.h"
#include "math.h"

class sensorntc
{	
	public:
		sensorntc (int pinntc);
		double leontc();
		
	
	private:
		int _pinntc;
		
};

#endif
