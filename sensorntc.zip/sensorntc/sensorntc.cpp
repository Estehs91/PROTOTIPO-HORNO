#include "arduino.h"
#include "sensorntc.h"


sensorntc::sensorntc(int pinntc){
 _pinntc=pinntc;
}

double sensorntc::leontc() {
 double tempc;
 tempc = log(10000.0*((1024.0/analogRead(_pinntc)-1))); 
 tempc = 1 / (0.001129148 + (0.000234125 + (0.0000000876741 * tempc * tempc ))* tempc );
 tempc = int(tempc - 273.15);            
 return tempc;
}

