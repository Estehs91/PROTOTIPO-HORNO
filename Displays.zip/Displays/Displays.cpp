#include "Displays.h"

Displays displays;

void _muestro (void)
{
	displays.muestro();
}
void Displays::init(byte nD, byte nC, byte nB, byte nA, byte ntr1, byte ntr2) {
  D = nD;
  C = nC;
  B = nB;
  A = nA;
  tr1 = ntr1;
  tr2 = ntr2;
  
  pinMode(D,OUTPUT);
  pinMode(C,OUTPUT);
  pinMode(B,OUTPUT); 
  pinMode(A,OUTPUT);
  pinMode(tr1,OUTPUT);
  pinMode(tr2,OUTPUT);
  
  dato = 0;
  
  disp = 0;
  
  Timer1.initialize(10000);//10mseg
  Timer1.attachInterrupt(_muestro);
  
}

void Displays::muestro(void) {

  switch(disp)
  {
	case 0:
		bin2pins(dato / 10);
	    digitalWrite(tr2,LOW);
		digitalWrite(tr1,HIGH);
		disp++;
	break;
	case 1:
		bin2pins(dato % 10);
		digitalWrite(tr1,LOW);
		digitalWrite(tr2,HIGH);
		disp = 0;
	break;
	default:
		disp = 0;
	break;
  }
}

void Displays::cargarDato(byte nDato)
{
	dato = nDato %100;
}


void Displays::bin2pins(byte dato)
{
	digitalWrite(D, (dato >> 3) & 1);
	digitalWrite(C, (dato >> 2) & 1);
	digitalWrite(B, (dato >> 1) & 1);
	digitalWrite(A, (dato) & 1);
}

