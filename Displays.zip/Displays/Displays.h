#ifndef _DISPLAYS_H_
#define _DISPLAYS_H_

#include "Arduino.h"
#include <TimerOne.h>

class Displays {
	private:
		byte dato;
		byte disp;
		byte D;
		byte C;
		byte B;
		byte A;
		byte tr1;
		byte tr2;
		void bin2pins (byte dato);
	public:
		void muestro (void);
		void init (byte nD, byte nC, byte nB, byte nA, byte ntr1, byte ntr2) ;
		void cargarDato(byte nDato);

};

extern Displays displays;

#endif
